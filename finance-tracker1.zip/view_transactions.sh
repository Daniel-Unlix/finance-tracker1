#!/bin/bash
echo "All Transactions:"
echo "ID,Date,Category,Description,Amount"
cat transactions.txt
