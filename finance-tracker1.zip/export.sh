#!/bin/bash
cp transactions.txt transactions_export.csv
echo "Transactions exported to transactions_export.csv"
